"use client"

import { useEffect, useRef } from "react"
import { createChart } from "lightweight-charts"

export function TradingViewChart() {
  const chartContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (chartContainerRef.current) {
      const chart = createChart(chartContainerRef.current, {
        layout: {
          background: { color: "#1A1B1E" },
          textColor: "#DDD",
        },
        grid: {
          vertLines: { color: "#2B2B43" },
          horzLines: { color: "#2B2B43" },
        },
        width: chartContainerRef.current.clientWidth,
        height: 400,
      })

      const candleSeries = chart.addCandlestickSeries({
        upColor: "#26a69a",
        downColor: "#ef5350",
        borderVisible: false,
        wickUpColor: "#26a69a",
        wickDownColor: "#ef5350",
      })

      // Sample data - replace with real-time data
      candleSeries.setData([
        { time: "2024-01-17", open: 101000, high: 102249.8, low: 99333.6, close: 101783.4 },
        // Add more candles...
      ])

      const handleResize = () => {
        if (chartContainerRef.current) {
          chart.applyOptions({
            width: chartContainerRef.current.clientWidth,
          })
        }
      }

      window.addEventListener("resize", handleResize)

      return () => {
        window.removeEventListener("resize", handleResize)
        chart.remove()
      }
    }
  }, [])

  return <div ref={chartContainerRef} className="w-full h-full" />
}

