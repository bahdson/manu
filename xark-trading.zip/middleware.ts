import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { verify } from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Add paths that don't require authentication
const publicPaths = ["/auth/login", "/auth/register"]

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Check if the path is public
  if (publicPaths.includes(pathname)) {
    return NextResponse.next()
  }

  // Get token from header
  const token = request.headers.get("authorization")?.split(" ")[1]

  if (!token) {
    return NextResponse.redirect(new URL("/auth/login", request.url))
  }

  try {
    // Verify token
    verify(token, JWT_SECRET)
    return NextResponse.next()
  } catch (error) {
    return NextResponse.redirect(new URL("/auth/login", request.url))
  }
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * 1. /api/auth/** (authentication endpoints)
     * 2. /_next/** (Next.js internals)
     * 3. /static/** (static files)
     * 4. /favicon.ico, /sitemap.xml (public files)
     */
    "/((?!api/auth|_next|static|favicon.ico|sitemap.xml).*)",
  ],
}

