import { NextResponse } from "next/server"
import { sign } from "jsonwebtoken"
import { hash, compare } from "bcrypt"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json()
    console.log("Login attempt for email:", email)

    // Simulate database check
    const user = {
      id: 1,
      email: "demo@example.com",
      passwordHash: await hash("password123", 10),
    }

    if (email !== user.email) {
      console.log("User not found")
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const isValid = await compare(password, user.passwordHash)

    if (!isValid) {
      console.log("Invalid password")
      return NextResponse.json({ error: "Invalid password" }, { status: 401 })
    }

    // Generate JWT token
    const token = sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: "24h" })

    console.log("Login successful for user:", email)
    return NextResponse.json({ token })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

