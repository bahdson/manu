"use client"

import { useState } from "react"
import { Bell, Book, ChevronDown, History, LineChart, Settings } from "lucide-react"
import { createChart, ColorType } from "lightweight-charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"

export default function TradingPage() {
  const [orderType, setOrderType] = useState<"market" | "limit">("market")
  const [amount, setAmount] = useState("0.01")

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      {/* Header */}
      <header className="flex h-14 items-center justify-between border-b px-4">
        <div className="flex items-center gap-8">
          <h1 className="text-xl font-bold">Xark</h1>
          <nav className="hidden md:flex items-center gap-6">
            <Button variant="ghost">Trading</Button>
            <Button variant="ghost">Market</Button>
            <Button variant="ghost">Platforms</Button>
            <Button variant="ghost">Tools</Button>
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm">
            DEMO
          </Button>
          <Button variant="outline" size="sm">
            REAL
          </Button>
          <Button size="icon" variant="ghost">
            <Bell className="h-5 w-5" />
          </Button>
          <Button size="icon" variant="ghost">
            <Settings className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 gap-4 p-4">
        {/* Left Column - Market List */}
        <Card className="hidden lg:flex w-64 flex-col">
          <div className="p-4 border-b">
            <Input placeholder="Search markets..." />
          </div>
          <Tabs defaultValue="hot" className="flex-1">
            <TabsList className="w-full justify-start rounded-none border-b px-4">
              <TabsTrigger value="hot">Hot</TabsTrigger>
              <TabsTrigger value="forex">Forex</TabsTrigger>
              <TabsTrigger value="crypto">Crypto</TabsTrigger>
            </TabsList>
            <TabsContent value="hot" className="p-0">
              <div className="space-y-1 p-2">
                {[
                  { symbol: "BTC/USDT", price: "101783.40", change: "+1.474%" },
                  { symbol: "ETH/USDT", price: "3403.26", change: "+2.024%" },
                  { symbol: "XAU/USD", price: "2705.01", change: "-0.398%" },
                ].map((market) => (
                  <Button key={market.symbol} variant="ghost" className="w-full justify-start px-2 py-1.5">
                    <div className="flex flex-1 items-center justify-between">
                      <span>{market.symbol}</span>
                      <div className="text-right">
                        <div>{market.price}</div>
                        <div className={market.change.startsWith("+") ? "text-green-500" : "text-red-500"}>
                          {market.change}
                        </div>
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </Card>

        {/* Center Column - Chart */}
        <Card className="flex-1">
          <div className="flex items-center justify-between border-b p-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-orange-500" />
                <div>
                  <div className="font-bold">BTC/USDT</div>
                  <div className="text-sm text-muted-foreground">Bitcoin</div>
                </div>
              </div>
              <div className="text-2xl font-bold text-green-500">101783.40</div>
              <div className="text-green-500">+1.474%</div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <LineChart className="mr-2 h-4 w-4" />
                Indicators
              </Button>
              <Button variant="outline" size="sm">
                <History className="mr-2 h-4 w-4" />
                Time
              </Button>
            </div>
          </div>
          <div className="aspect-[2/1] w-full" id="chart" />
        </Card>

        {/* Right Column - Order Form */}
        <Card className="w-80 flex-none">
          <div className="flex border-b">
            <Button
              variant={orderType === "market" ? "default" : "ghost"}
              className="flex-1 rounded-none"
              onClick={() => setOrderType("market")}
            >
              Market
            </Button>
            <Button
              variant={orderType === "limit" ? "default" : "ghost"}
              className="flex-1 rounded-none"
              onClick={() => setOrderType("limit")}
            >
              Limit
            </Button>
          </div>
          <div className="p-4 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Amount (BTC)</label>
              <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
              <div className="grid grid-cols-5 gap-2">
                {["0.01", "0.1", "0.5", "1.0", "5.0"].map((value) => (
                  <Button key={value} variant="outline" size="sm" onClick={() => setAmount(value)}>
                    {value}
                  </Button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Take Profit</label>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Stop Loss</label>
                <Switch />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button className="bg-green-500 hover:bg-green-600">Buy</Button>
              <Button className="bg-red-500 hover:bg-red-600">Sell</Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

